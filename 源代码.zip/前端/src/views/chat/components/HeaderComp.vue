<template>
  <div class="chat-main-header">
    <div class="chat-main-header-left">
      <i class="iconfont icon-sidebarcebianlan" v-if="sidebarFoldStore.sidebarFold"
        @click="sidebarFoldStore.toggleSidebarFold()"></i>
      <i class="iconfont icon-xinhuihua" @click="newSession()"></i>
    </div>
    <el-dropdown v-if="userStore.token" trigger="click">
      <div class="user-avatar">
        <el-avatar :icon="UserFilled" :size="35" />
        <el-icon>
          <ArrowDownBold />
        </el-icon>
      </div>
      <template #dropdown>
        <el-dropdown-menu>
          <el-dropdown-item>
            <span>姓名：{{ userStore.userInfo.user_name }}</span>
          </el-dropdown-item>
          <el-dropdown-item>
            <span>邮箱：{{ userStore.userInfo.user_email }}</span>
          </el-dropdown-item>
          <el-dropdown-item divided @click="logout()">退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
    <el-button v-else link @click="userStore.showLoginDialog = true">登录</el-button>
  </div>
</template>

<script setup>
import { watch } from 'vue';
import { UserFilled } from '@element-plus/icons-vue';
import useUserStore from '@/stores/user';
import useSidebarFoldStore from '@/stores/sidebarFold.js';
import { getUserInfoAPI } from '@/api';

const userStore = useUserStore();
const sidebarFoldStore = useSidebarFoldStore();

const emit = defineEmits(['newSession','logout']);

function newSession() {
  emit('newSession');
}

// 获取用户信息
function getUserInfo() {
  getUserInfoAPI().then(res => {
    userStore.setUserInfo(res.data);
  });
}
watch(() => userStore.token, (newV) => {
  if (newV) {
    getUserInfo();
  }
}, { immediate: true });


// 退出登录
function logout() {
  ElMessageBox.confirm('确定退出登录吗？', '提示', {
    type: 'warning',
  }).then(()=>{
    userStore.logout();
    emit('logout');
  });
}
</script>

<style lang="scss" scoped>
.chat-main-header {
  padding: 10px;
  display: flex;
  justify-content: space-between;

  .chat-main-header-left {
    display: flex;
    gap: 10px;

    .icon-sidebarcebianlan,
    .icon-xinhuihua {
      color: var(--text-color-placeholder);
      font-size: 20px;
      cursor: pointer;
    }
  }

  .user-avatar {
    display: flex;
    align-items: center;
    gap: 5px;
    cursor: pointer;
  }
}
</style>
