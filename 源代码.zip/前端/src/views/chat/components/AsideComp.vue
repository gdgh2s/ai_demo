<template>
  <div class="aside" :style="{ transform: sidebarFoldStore.sidebarFold ? 'translateX(-240px)' : 'translateX(0)' }">
    <div class="top">
      <p>LOGO</p>
      <i class="iconfont icon-sidebarcebianlan" @click="sidebarFoldStore.toggleSidebarFold()"></i>
    </div>
    <div class="chat-history">
      <div class="title">
        <i class="iconfont icon-shizhong"></i>
        <span>历史会话</span>
      </div>
      <ul class="history-list">
        <li v-for="(item) in historyList" :key="item.session_id" @click="goDetail(item)">{{ item.title }}</li>
      </ul>
    </div>
    <div class="bottom">
      <div></div>
      <el-switch v-model="themeStore.isDark" :active-action-icon="Moon" :inactive-action-icon="Sunny" />
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from "vue";
import { useRouter } from 'vue-router';
import { Sunny, Moon } from '@element-plus/icons-vue';
import useSidebarFoldStore from '@/stores/sidebarFold.js';
import useThemeStore from '@/stores/theme.js';
import useUserStore from "@/stores/user.js";
import { getHistoryListAPI } from '@/api';

const sidebarFoldStore = useSidebarFoldStore();
const themeStore = useThemeStore();
const router = useRouter();

const userStore = useUserStore();

const historyList = ref([]);
function getHistoryList() {
  getHistoryListAPI().then(res => {
    historyList.value = res.data;
  });
}
watch(() => userStore.token, () => {
  if (userStore.token) {
    getHistoryList();
  } else {
    historyList.value = [];
  }
}, { immediate: true })


function goDetail(item) {
  router.replace({
    name: 'chat',
    params: {
      session_id: item.session_id
    }
  });
}

</script>

<style lang="scss" scoped>
.aside {
  height: 100%;
  overflow: hidden;
  width: 240px;
  transform: translateX(-240px);
  transition: transform .2s linear;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
  background-color: var(--background-lighter);

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: var(--text-color-placeholder);
    padding: 0 10px;

    .icon-sidebarcebianlan {
      color: var(--text-color-placeholder);
      font-size: 20px;
      cursor: pointer;
    }
  }

  .chat-history {
    color: var(--text-color-primary);
    padding: 0 10px;

    .title {
      .icon-shizhong {
        margin-right: 5px;
        font-size: 18px;
      }
    }

    .history-list {
      padding-left: 15px;
      height: calc(100vh - 150px);
      overflow-y: auto;

      &::-webkit-scrollbar {
        width: 0;
        height: 0;
        display: none;
      }

      li {
        list-style: none;
        cursor: pointer;
        font-size: 15px;
        margin-bottom: 5px;
      }
    }
  }

  .bottom {
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;

    .el-switch {
      --el-switch-on-color: var(--background-darker);
    }
  }
}
</style>
