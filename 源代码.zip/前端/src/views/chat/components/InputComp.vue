<template>
  <div class="input-comp-view animate__animated animate__fadeInUp">
    <h1 class="logo" v-show="props.logoShow">LOGO</h1>
    <div class="input-wrapper">
      <el-input v-model="text" :autosize="{ minRows: 2, maxRows: 10 }" type="textarea" placeholder="请输入您的问题"
        @keydown="handleKeydown" resize="none" />
      <div class="input-functional-area">
        <div></div>
        <el-button class="send-btn" palin circle @click="send()">
          <el-icon :size="20">
            <Top />
          </el-icon>
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import useUserStore from '@/stores/user.js';

const userStore = useUserStore();

const props = defineProps({
  logoShow: {
    type: Boolean,
    default: true
  },
  disabled: {
    type: Boolean,
    default: false
  }
});
const emit = defineEmits(['send']);


const text = ref('');
function send() {
  if(!userStore.token){
    userStore.showLoginDialog = true;
    return;
  }
  if (props.disabled) {
    ElMessage.warning('请等待本次问答结束');
    return;
  }
  if (!text.value.trim()) {
    ElMessage.warning('请输入内容');
    return;
  }
  emit('send', text.value);
  text.value = '';
}

function handleKeydown(e) {
  if (e.keyCode === 13 && !e.shiftKey) {
    e.preventDefault();
    send();
  }
}
</script>

<style lang="scss" scoped>
.input-comp-view {
  --animate-duration: 0.2s;
  width: 100%;
  .logo {
    font-size: 80px;
    font-weight: bold;
    margin: 0;
    text-align: center;
  }

  .input-wrapper {
    width: 100%;
    border: 1px solid var(--border-color);
    border-radius: 20px;
    overflow: hidden;
    flex-shrink: 0;

    :deep(.el-textarea) {
      .el-textarea__inner {
        font-size: 16px;
        box-shadow: none;
        padding: 10px 20px;
        background-color: var(--background-lighter);

        &::-webkit-scrollbar {
          display: none;
          width: 0;
          height: 0;
        }
      }
    }

    .input-functional-area {
      background-color: var(--background-lighter);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px;

      .send-btn {
        border-radius: 10px;
      }
    }
  }
}
</style>
