<template>
  <div class="chat">
    <AsideComp />
    <div class="main" :style="{ marginLeft: mainMarginLeft }">
      <HeaderComp @newSession="newSession()" @logout="newSession()"/>
      <div class="main-container">
        <div class="chat-list" v-show="chatList.length > 0" ref="chatListRef">
          <div v-for="(item, index) in chatList" :key="index">
            <div v-if="item.role === 'assistant'" class="ai-content">
              <img class="ai-avatar" :class="{ 'waiting': item.state === 'waiting' }" src="../../assets/images/ai.png"
                alt="">
              <div class="content">
                <div class="content-text" v-html="parseMarkdown(item.content)"></div>
                <el-icon class="ai_cursor" v-if="sendDisabled && chatList.length - 1 === index">
                  <SemiSelect />
                </el-icon>
              </div>
            </div>
            <div v-if="item.role === 'user'" class="user-content">
              <p class="content animate__animated animate__fadeInRight">{{ item.content }}</p>
            </div>
          </div>
        </div>
        <InputComp :disabled="sendDisabled" :logoShow="chatList.length === 0" @send="sendHandler" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { nextTick, ref, onMounted, onBeforeUnmount, computed, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import markdownit from 'markdown-it';
import 'highlight.js/styles/atom-one-dark.min.css';
import hljs from 'highlight.js';
import useSidebarFoldStore from '@/stores/sidebarFold.js';
import AsideComp from './components/AsideComp.vue';
import InputComp from './components/InputComp.vue';
import FetchStream from '@/utils/fetchStream.js';
import Typed from '@/utils/typed.js';
import HeaderComp from './components/HeaderComp.vue';
import { getChatHistoryAPI } from '@/api';

const route = useRoute();
const router = useRouter();

// *获取历史记录
let session_id = route.params.session_id;
function getHistory() {
  getChatHistoryAPI(session_id).then(res => {
    chatList.value = res.data.messages || [];
    scrollToBottom();
  });
}
watch(() => route.params.session_id, (newV) => {
  if (newV) {
    session_id = newV;
    getHistory();
  }
}, { immediate: true });



const chatListRef = ref(null);
const sendDisabled = ref(false);
const chatList = ref([]);

function sendHandler(val) {
  sendDisabled.value = true;
  chatList.value.push({
    role: 'user',
    content: val
  }, {
    role: 'assistant',
    content: '',
    state: 'waiting'
  });
  const fetchStream = new FetchStream('/chat');
  fetchStream.onmessage = handleOnMessage;
  fetchStream.onerror = handleOnError;
  fetchStream.send({ human_prompt: val, session_id });
  scrollToBottom();
}

function handleOnMessage(message) {
  if (message.session_id) {
    session_id ||= message.session_id;
  }
  typed.append(message.content || '');
  if (!typed.isStart) {
    typed.start();
  }
}
function handleOnError() {
  chatList.value.at(-1).state = 'error';
  chatList.value.at(-1).content = '出错了，请稍后再试';
  sendDisabled.value = false;
}


// *新会话
function newSession() {
  router.replace('/chat');
  chatList.value = [];
  session_id = '';
  sendDisabled.value = false;
  userScrolled = false;
  typed.stop();
}


// *打字机逻辑
let typed;
function initTyped() {
  typed = new Typed();
  typed.onoutput = (char) => {
    chatList.value.at(-1).content += char;
    scrollToBottom();
  }
  typed.onfinish = () => {
    chatList.value.at(-1).state = 'finish';
    sendDisabled.value = false;
    typed.stop();
  }
}
initTyped();
// *打字机逻辑结束


// *markdown 解析逻辑
let md;
async function initMarkdownIt() {
  md = markdownit({
    highlight: (str, lang) => {
      if (lang && hljs.getLanguage(lang)) {
        try {
          return hljs.highlight(str, { language: lang }).value;
        } catch {
          console.log(`Language ${lang} not found`);
        }
      }
      return '';
    }
  });
}
initMarkdownIt();
function parseMarkdown(text) {
  return md.render(text);
}
// *markdown 解析逻辑结束


// *滚动逻辑
let userScrolled = false;

function scrollToBottom() {
  nextTick(() => {
    if (chatListRef.value && !userScrolled) {
      chatListRef.value.scrollTop = chatListRef.value.scrollHeight;
    }
  });
}

function scrollHandler() {
  userScrolled = true;
  // 判断是否滚动到底部
  if (chatListRef.value.scrollTop + chatListRef.value.clientHeight >= chatListRef.value.scrollHeight - 20) {
    userScrolled = false;
  }
}

onMounted(() => {
  chatListRef.value.addEventListener('scroll', scrollHandler);
});
onBeforeUnmount(() => {
  chatListRef.value.removeEventListener('scroll', scrollHandler);
});
// *滚动逻辑结束


// *折叠逻辑
const sidebarFoldStore = useSidebarFoldStore();
const mainMarginLeft = computed(() => {
  const innerWidth = window.innerWidth;
  return !sidebarFoldStore.sidebarFold && innerWidth > 768 ? '240px' : '0';
});
// *折叠逻辑结束

</script>

<style lang="scss" scoped>
.chat {
  height: 100vh;
  padding: 5px;
  background-color: var(--background-lighter);
  position: relative;

  .main {
    border-radius: 8px;
    border: 1px solid var(--border-color);
    background-color: var(--background-base);
    height: 100%;
    transition: margin .2s ease-in-out;

    .main-container {
      height: calc(100% - 60px);
      max-width: 768px;
      margin: 0 auto;
      display: flex;
      gap: 20px;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 20px;

      .chat-list {
        flex-grow: 1;
        width: 100%;
        overflow: auto;
        color: var(--text-color-primary);

        &::-webkit-scrollbar {
          display: none;
          width: 0;
          height: 0;
        }

        .ai-content {
          display: flex;
          gap: 15px;

          .ai-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            user-select: none;

            @keyframes rotate {
              0% {
                transform: rotate(0deg);
              }

              17% {
                transform: rotate(120deg);
              }

              35% {
                transform: rotate(120deg);
              }

              52% {
                transform: rotate(240deg);
              }

              69% {
                transform: rotate(240deg);
              }

              87% {
                transform: rotate(360deg);
              }

              100% {
                transform: rotate(360deg);
              }
            }

            &.waiting {
              animation: rotate 2s linear infinite;
            }
          }

          .content {
            max-width: 80%;
            margin: 0;

            @keyframes flicker {
              0% {
                opacity: 1;
              }

              50% {
                opacity: 0;
              }

              100% {
                opacity: 1;
              }
            }

            .content-text {
              display: inline;

              >:last-child {
                display: inline;
              }
            }

            .ai_cursor {
              transform: translateY(8px);
              animation: flicker 0.5s infinite;
            }
          }
        }

        .user-content {
          display: flex;
          justify-content: flex-end;

          .content {
            --animate-duration: 0.2s;
            border-radius: 10px;
            background-color: var(--background-lighter);
            padding: 10px 15px;
            white-space: pre-wrap;
            max-width: 80%;
          }
        }
      }
    }
  }
}
</style>
