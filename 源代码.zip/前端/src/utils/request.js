import axios from 'axios';

const instance = axios.create({
  baseURL: import.meta.env.VITE_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  }
});

// 请求拦截器
instance.interceptors.request.use(
  (config) => {
    // 在发送请求之前做些什么
    const token = localStorage.getItem('token');
    config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => {
    // 对请求错误做些什么
    return Promise.reject(error);
  }
);

// 响应拦截器
instance.interceptors.response.use(
  (response) => {
    // 对响应数据做点什么
    if (response.data.code !== 1) {
      // 如果调用接口时候传递了展示错误信息，则展示错误信息
      if (response.config.showError) {
        ElMessage({
          message: response.data.messages || '网络异常，请稍后重试',
          type: 'error',
          grouping: true,
          plain: true,
        });
      }
      return Promise.reject(response.data);
    }
    return Promise.resolve(response.data);
  },
  (error) => {
    // 对响应错误做点什么
    return Promise.reject(error);
  }
);


function request(config) {
  return new Promise((resove, reject) => {
    instance({
      url: config.url,
      method: config.method || 'post',
      data: config.data,
      showError: config.showError ?? true
    }).then((res) => {
      resove(res);
    }).catch((err) => {
      reject(err);
    });
  });
}

export default request;
