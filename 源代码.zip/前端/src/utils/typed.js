
class Typed {

  options = {
    speed: 33,
  }
  strings = [];
  isStart = false;
  isTyping = false;
  finishTimer = null;

  constructor(options = {}) {
    this.options = { ...this.options, ...options }
  }

  start(text) {
    this.isStart = true;
    this.append(text);
    return this;
  }

  append(text) {
    if (typeof text === 'string') {
      this.strings.push(text);
    }
    this.type();
    return this;
  }

  async type() {
    if (this.isTyping || !this.isStart) return;
    this.isTyping = true;
    while (this.isTyping) {
      const text = this.strings.shift();
      const step = Math.min(this.strings.length + 1, 5);
      if (!text) {
        this.isTyping = false;
        this.finishTimer = setTimeout(this.onfinish, 3000);
      } else {
        clearTimeout(this.finishTimer);
        for (let i = 0; i < text.length; i += step) {
          if (!this.isTyping) break; // 检查是否停止
          await new Promise(resolve => setTimeout(resolve, this.options.speed));
          this.onoutput(text.slice(i, i + step));
        }
      }
    }
  }

  stop() {
    this.isTyping = false;
    this.isStart = false;
    this.strings = [];
    return this;
  }

  onoutput() {

  }

  onfinish() {

  }

}

export default Typed;
