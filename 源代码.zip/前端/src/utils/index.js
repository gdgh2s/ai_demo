
// 是否是移动设备
export const isMobile = () => {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
};

// 正则验证
const RegKeys = {
  // 邮箱
  email: /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/,
  // 手机号
  phone: /^1[3456789]\d{9}$/,
  // 身份证
  idCard: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
}
/**
 * 正则验证
 * @param {keyof typeof RegKeys} regKey 正则key
 * @param {string} val 验证值
 * @returns {boolean}
 */
export const regTest = (regKey, val) => {
  return RegKeys[regKey].test(val);
}


/**
 * 对象转urlencoded
 * @param {object} obj
 * @returns {string}
 */
export const objectToUrlEncoded = (obj = {}) => {
  // 创建一个数组，用于存储键值对
  const keyValuePairs = [];
  // 遍历对象的键值对
  for (const key in obj) {
    const value = obj[key];
    // 对键和值进行编码，并拼接为 key=value 的形式
    keyValuePairs.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
  }
  // 使用 & 符号连接所有键值对
  return keyValuePairs.join('&');
}
