import { objectToUrlEncoded } from '@/utils';

class FetchStream {

  isSending = false;
  url = '';
  options = {};

  constructor(url, options = {}) {
    this.url = import.meta.env.VITE_BASE_URL + url;
    this.options = { ...this.options, ...options };
    this.onready();
  }

  onready() {
    console.log('Stream ready');
  }

  async send(data) {
    if (this.isSending) {
      console.warn('Stream is already sending');
      return;
    }
    this.isSending = true;
    const token = localStorage.getItem('token');
    const options = {
      method: 'POST',
      body: objectToUrlEncoded(data),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Bearer ${token}`
      },
      ...this.options
    }
    try {
      const response = await window.fetch(this.url, options);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) {
          this.onfinish();
          break;
        }
        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');
        if (lines.length > 1 && /^data: /.test(lines[0])) {
          const parsedData = JSON.parse(lines[0].slice(6));
          this.onmessage(parsedData);
        }
      }
      this.isSending = false;
    } catch (error) {
      this.onerror(error);
      this.isSending = false;
    }
  }

  onmessage() {

  }

  onfinish() {
    console.log('Stream finished');
  }

  onerror(error) {
    console.error(error);
  }

}

export default FetchStream;
