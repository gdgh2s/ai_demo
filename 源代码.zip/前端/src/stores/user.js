import { defineStore } from 'pinia'
import { ref } from 'vue';

const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token'));

  function setToken(value) {
    token.value = value;
    localStorage.setItem('token', value);
  }

  function logout() {
    token.value = null;
    localStorage.clear();
  }

  const showLoginDialog = ref(false);

  const userInfo = ref({
    user_email:'',
    user_name:'',
    user_id:''
  });
  function setUserInfo(value = {}) {
    userInfo.value = value;
    localStorage.setItem('userInfo', JSON.stringify(value));
  }

  return { token, setToken, logout, showLoginDialog, userInfo, setUserInfo };
});

export default useUserStore;
