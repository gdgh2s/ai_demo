import { defineStore } from 'pinia'
import { onBeforeUnmount, ref, watch } from 'vue';

const useThemeStore = defineStore('theme', () => {

  const isDark = ref(window.matchMedia('(prefers-color-scheme: dark)').matches);
  const themeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  themeMediaQuery.addEventListener('change', handleThemeChange);
  function handleThemeChange(e) {
    if (e.matches) {
      document.documentElement.classList.add('dark');
      isDark.value = true;
    } else {
      document.documentElement.classList.remove('dark');
      isDark.value = false;
    }
  }
  handleThemeChange(themeMediaQuery);

  function changeTheme(theme) {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      isDark.value = true;
    } else {
      document.documentElement.classList.remove('dark');
      isDark.value = false;
    }
  }

  watch(isDark, (newV) => {
    changeTheme(newV ? 'dark' : 'light');
  });

  onBeforeUnmount(() => {
    themeMediaQuery.removeEventListener('change', handleThemeChange);
  });

  return { isDark, changeTheme }
});

export default useThemeStore;
