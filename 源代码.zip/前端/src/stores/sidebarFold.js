import { defineStore } from 'pinia'
import { ref } from 'vue';

const useSidebarFoldStore = defineStore('sidebarFold', () => {
  const sidebarFold = ref(localStorage.getItem('sidebarFold') === 'true');

  const toggleSidebarFold = () => {
    sidebarFold.value = !sidebarFold.value;
    localStorage.setItem('sidebarFold', sidebarFold.value);
  }

  return { sidebarFold, toggleSidebarFold };
});

export default useSidebarFoldStore;
