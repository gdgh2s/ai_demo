import request from "@/utils/request.js";

// 登录
export const loginAPI = (data) => {
  return request({
    url: '/login',
    data,
  });
}

// 获取聊天记录
export const getHistoryListAPI = (data) => {
  return request({
    url: '/sessions_list',
    data,
  });
}

// 获取指定session_id的聊天记录
export const getChatHistoryAPI = (data) => {
  return request({
    url: `/history?session_id=${data}`,
    method: 'GET',
  });
}

// 获取用户信息
export const getUserInfoAPI = () => {
  return request({
    url: '/userinfo',
  });
}


// 注册用户
export const registerAPI = (data) => {
  return request({
    url: '/register',
    data,
  });
}
