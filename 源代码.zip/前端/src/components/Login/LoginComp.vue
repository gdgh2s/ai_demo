<template>
  <div style="padding: 20px;">
    <el-form :model="formData" :rules="rules" ref="formRef" label-width="auto" size="large">
      <el-form-item label="邮箱" prop="username">
        <el-input v-model="formData.username" placeholder="请输入邮箱"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input v-model="formData.password" placeholder="请输入密码"></el-input>
      </el-form-item>
      <el-form-item v-if="mode === 'registerMode'" label="姓名" prop="name">
        <el-input v-model="formData.name" placeholder="请输入密码"></el-input>
      </el-form-item>
    </el-form>
    <div class="btn-wrapper">
      <el-button @click="cancle()">取消</el-button>
      <el-button type="primary" @click="login()">{{ mode === 'loginMode' ? '登录' : '注册' }}</el-button>
      <br>
      <el-button v-if="mode === 'loginMode'" class="reg" link @click="changeMode('registerMode')">没有账号，点击注册</el-button>
      <el-button v-else class="reg" link @click="changeMode('loginMode')">已有账号，点击登录</el-button>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue';
import useUserStore from '@/stores/user';
import { loginAPI, registerAPI } from '@/api';
import { regTest } from '@/utils';

const userStore = useUserStore();
const { setToken } = userStore;

const emit = defineEmits(['loginMode', 'registerMode']);
const mode = ref('loginMode');
function changeMode(val) {
  mode.value = val;
  emit(val);
}


const formData = reactive({
  username: '',
  password: '',
  name: ''
});

const btnLoading = ref(false);

function login() {
  formRef.value.validate((valid) => {
    if (valid) {
      btnLoading.value = true;
      if (mode.value === 'loginMode') {
        loginAPI(formData).then((res) => {
          setToken(res.data.access_token);
          userStore.showLoginDialog = false;
          ElMessage.success('登录成功');
        }).finally(() => {
          btnLoading.value = false;
        });
      } else {
        registerAPI({
          ...formData,
          email: formData.username,
        }).then(() => {
          ElMessage.success('注册成功');
          changeMode('loginMode');
        });
      }
    }
  });
}

function cancle() {
  userStore.showLoginDialog = false;
  formRef.value.resetFields();
}

const formRef = ref();
const rules = {
  username: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value && !regTest('email', value)) {
          return callback(new Error('请输入正确的邮箱格式'));
        }
        callback();
      },
      trigger: 'blur'
    }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
  ],
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' },
  ]
}
</script>

<style lang="scss" scoped>
.btn-wrapper {
  text-align: center;

  .reg {
    text-align: center;
    margin-top: 10px;
  }
}
</style>
