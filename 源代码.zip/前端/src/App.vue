<template>
  <router-view></router-view>
  <el-dialog :title="loginTitle" v-model="userStore.showLoginDialog" header-class="dialog-custom-header-class"
    :close-on-click-modal="false" :close-on-press-escape="false" :fullscreen="windowInnerWidth < 768" center
    width="450px">
    <LoginComp @loginMode="loginTitle = '登录'" @registerMode="loginTitle = '注册'"/>
  </el-dialog>
</template>

<script setup>
import { onBeforeUnmount, ref } from 'vue';
import LoginComp from '@/components/Login/LoginComp.vue';
import useUserStore from '@/stores/user.js';
import useThemeStore from '@/stores/theme.js';
useThemeStore();
const userStore = useUserStore();

const loginTitle = ref('登录');

const windowInnerWidth = ref(window.innerWidth);
window.addEventListener('resize', handleResize);
function handleResize() {
  windowInnerWidth.value = window.innerWidth;
}

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize);
});
</script>
