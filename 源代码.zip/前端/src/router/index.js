import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/chat'
    },
    {
      path: '/chat/:session_id?',
      name: 'chat',
      component: () => import('@/views/chat/chatView.vue'),
      meta: {
        title: 'chat'
      }
    }
  ],
})

export default router
