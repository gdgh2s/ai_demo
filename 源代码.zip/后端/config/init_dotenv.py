import dotenv
import os

# 加载环境变量
dotenv.load_dotenv(dotenv_path='../project.env', verbose=True)

# sql数据库配置
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD")
MySQL_USER = os.getenv("MYSQL_USER")
MYSQL_HOST = os.getenv('MYSQL_HOST')
MYSQL_PORT = os.getenv('MYSQL_PORT')
MYSQL_DB = os.getenv('MYSQL_DB')

# LLM配置
MODEL_NAME = os.getenv('MODEL_NAME')
LLM_BASE_URL = os.getenv('LLM_BASE_URL')
LLM_API_KEY = os.getenv('LLM_API_KEY')

# JWT配置
SECRET_KEY = os.getenv('SECRET_KEY')
ALGORITHM = os.getenv('ALGORITHM')
ACCESS_TOKEN_EXPIRE_DAYS = int(os.getenv('ACCESS_TOKEN_EXPIRE_DAYS'))