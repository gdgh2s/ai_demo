import asyncio
import json

from openai import AsyncOpenAI

from config.init_dotenv import LLM_API_KEY, LLM_BASE_URL, MODEL_NAME
from config.log_config import log
from db.chat_messages import get_session_message, add_system_message, add_ai_message, add_human_message


async def chat_stream(
        session_id: int | None = None,
        system_prompt: str = "你是一个乐于助人的AI助手",
        human_prompt: str = "您好"
):
    client = AsyncOpenAI(
        api_key=LLM_API_KEY,
        base_url=LLM_BASE_URL,
    )

    # 消息列表
    messages_list = []
    session_messages = get_session_message(session_id=session_id)
    if session_messages is not None:
        for message in session_messages:
            messages_list.append({"role": message.role, "content": message.content})
        messages_list.append({"role": "user", "content": human_prompt})
    else:
        messages_list = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": human_prompt},
        ]
    try:
        # 调用API进行对话
        ai_message = ""
        async for chunk in await client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages_list,
                stream=True,
                stream_options={"include_usage": True}
        ):
            # 规定SSE协议格式
            data = {"event": "chat_message", "session_id": session_id, "content": None, "usage": None}
            if chunk.choices and chunk.choices[0].delta.content:
                data["content"] = chunk.choices[0].delta.content
                ai_message += chunk.choices[0].delta.content
            if chunk.usage:
                data["usage"] = {
                    "输入token": chunk.usage.prompt_tokens,
                    "输出token": chunk.usage.completion_tokens,
                    "总共token": chunk.usage.total_tokens
                }
            if data["content"] or data["usage"]:  # 只发送有内容的数据
                # 格式化为SSE协议格式
                yield json.dumps(data, ensure_ascii=False)
        # 数据库添加消息
        # add_system_message(session_id=session_id, content=system_prompt)
        add_human_message(session_id=session_id, content=human_prompt)
        add_ai_message(session_id=session_id, content=ai_message)
        # print(f"messages: {messages_list}")
    except Exception as e:
        log.warning(f"发生错误:{e}")
    finally:
        await client.close()


if __name__ == "__main__":
    async def main():
        try:
            async for chunk in chat_stream(
                    session_id=1,
                    system_prompt="你是一个乐于助人的AI助手",
                    human_prompt="你还记得我吗?"
            ):
                print(chunk)
        except Exception as e:
            print(f"主程序发生错误: {e}")


    asyncio.run(main())
