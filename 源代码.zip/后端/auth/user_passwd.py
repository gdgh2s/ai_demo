from passlib.context import CryptContext

# 密码哈希处理
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# 验证密码哈希值是否匹配
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


# 获取密码的哈希值
def get_password_hash(password) -> str:
    return pwd_context.hash(password)


if __name__ == '__main__':
    # 测试1:测试是否可以生成哈希值.
    print(f"密码:{get_password_hash("1234565")}")
    # 测试2:测试是否可以验证哈希值
    print(f"{verify_password("123456", get_password_hash("123456"))}")
    print(f"{verify_password("123456", get_password_hash("错误密码"))}")
