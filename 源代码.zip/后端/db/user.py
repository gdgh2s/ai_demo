from datetime import datetime
from typing import List

from pydantic import EmailStr
from sqlmodel import Field, Session, SQLModel, select, Relationship

from auth.user_passwd import verify_password
from db.sql_engine import engine
from config.log_config import log


# 创建用户模型
class User(SQLModel, table=True):
    """
    用于存储用户的模型
    """
    __table_args__ = {'extend_existing': True}
    __tablename__ = 'user'
    # 字段
    id: int = Field(primary_key=True)
    name: str = Field()
    hashed_password: str = Field()
    token: str = Field(default="unknow")
    email: EmailStr = Field(unique=True)
    type: str = Field(default="normal")
    created_at: datetime = Field(default_factory=datetime.now)  # 使用 default_factory
    is_available: bool = Field(default=True)
    # 关系
    sessions: List["ChatSession"] = Relationship(back_populates="user", cascade_delete=True)

    def __str__(self):
        created_at_repr = self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        return (
            f"User(\n"
            f"  id={self.id!r}, \n"
            f"  name={self.name!r}, \n"
            f"  hashed_password={self.hashed_password!r}, \n"
            f"  token={self.token!r}, \n"
            f"  email={self.email!r}, \n"
            f"  type={self.type!r}, \n"
            f"  created_at={created_at_repr!r}, \n"
            f"  is_available={self.is_available!r}\n"
            f")"
        )


def authenticate_user(email: str, password: str) -> bool | User:
    # 确认邮箱是否被注册
    with Session(engine) as sql_session:
        statement = select(User).where(User.email == email)
        if user := sql_session.exec(statement).first():
            # 验证密码正确则返回 User 对象,错误则返回 False
            if verify_password(password, user.hashed_password):
                log.debug("用户密码正确")
                return user
            else:
                return False
        else:
            log.warning(f"邮箱未被注册,邮箱为{email}")
            return False


def add_user(name: str, hashed_password: str, email: EmailStr, type: str = "normal") -> None | int:
    """
    创建用户
    """
    # 确认邮箱是否被注册
    with Session(engine) as sql_session:
        # 构建查询语句
        statement = select(User).where(User.email == email)
        # 执行查询
        if resulet := sql_session.exec(statement).first():
            log.warning(f"邮箱已经被注册,邮箱为{email}")
            return resulet.id
        else:
            new_user = User(name=name, hashed_password=hashed_password, type=type, email=email)
            sql_session.add(new_user)
            sql_session.commit()
            sql_session.refresh(new_user)
            log.debug(f"添加用户: {new_user}")
            return None


def del_user(user_id: int) -> None:
    """
    删除用户
    """
    # 构建SQL会话
    with Session(engine) as sql_session:
        if user := sql_session.get_one(User, user_id):
            sql_session.delete(user)
            sql_session.commit()
            log.debug(f"删除用户: {user}")
        else:
            log.warning(f"删除用户失败,用户ID{user_id}")


def update_user_passwoord(user_id: int, new_password: str) -> None:
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        user.hashed_password = new_password
        sql_session.refresh(user)
        sql_session.commit()
        log.debug(f"用户更新密码: {user}")


def update_user_name(user_id: int, new_name: str) -> None:
    """
    更改用户名称
    """
    # 构建SQL会话
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        user.name = new_name
        sql_session.commit()
        sql_session.refresh(user)
        log.debug(f"用户更名: {user}")


def update_user_token(user_email: EmailStr, new_token: str) -> None:
    with Session(engine) as sql_session:
        statement = select(User).where(User.email == user_email)
        if user := sql_session.exec(statement).first():
            user.token = new_token
            sql_session.commit()
            sql_session.refresh(user)
        log.debug(f"用户更新令牌: {user}")


def user_token2user_id(user_token: str) -> int | None:
    with Session(engine) as sql_session:
        statement = select(User).where(User.token == user_token)
        if user := sql_session.exec(statement).first():
            return user.id
        else:
            log.warning(f"基于令牌查询ID失败,token:{user_token}")
            return None


def unavailable_user(user_id: int) -> None:
    """
    失活用户
    """
    # 构建SQL会话
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        user.is_available = False
        sql_session.commit()
        sql_session.refresh(user)
        log.debug(f"失活用户: {user}")


def available_user(user_id: int) -> None:
    """
    激活用户
    """
    # 构建SQL会话
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        user.is_available = True
        sql_session.commit()
        sql_session.refresh(user)
        log.debug(f"激活用户: {user}")


def update_user_type(user_id: int, new_type: str) -> None:
    """
    更改用户类型
    """
    # 构建SQL会话
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        user.type = new_type
        sql_session.refresh(user)
        sql_session.commit()
        log.debug(f"用户类型变更: {user}")


def get_user_info(user_id: int) -> User | None:
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        if user is not None:
            log.debug(f"用户查询成功: {user}")
            return user
        else:
            log.warning(f"用户查询失败: ID {user_id}")
            return None


def get_user_sessions(user_id: int) -> Session | None:
    with Session(engine) as sql_session:
        user = sql_session.get(User, user_id)
        if user is not None:
            sessions = user.sessions
            log.debug(f"用户会话列表查询成功: {sessions}")
            return sessions
        else:
            log.warning(f"用户会话列表查询失败: ID {user_id}")
            return None
