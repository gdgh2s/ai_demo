from datetime import datetime
from typing import List

from sqlmodel import Field, Session, SQLModel, Relationship

from db.sql_engine import engine
from config.log_config import log
from db.user import User


# 创建消息会话模型
class ChatSession(SQLModel, table=True):
    """
    用于存储用户会话的模型
    """
    __table_args__ = {'extend_existing': True}
    __tablename__ = 'session'
    # 字段
    id: int = Field(primary_key=True)
    created_at: datetime = Field(default_factory=datetime.now)  # 使用 default_factory
    title: str = Field(default="新建对话")
    # 外键
    user_id: int = Field(foreign_key="user.id")
    # 关系
    user: User = Relationship(back_populates="sessions")
    messages: List["ChatMessage"] = Relationship(back_populates="session", cascade_delete=True)

    def __str__(self):
        created_at_repr = self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        return (
            f"ChatSession(\n"
            f"  id={self.id!r}, \n"
            f"  user_id={self.user_id!r}, \n"
            f"  created_at={created_at_repr!r}, \n"
            f"  title={self.title!r}, \n"
            f")"
        )


def create_session(user_id: int):
    # 构建SQL会话
    with Session(engine) as sql_session:
        new_session = ChatSession(user_id=user_id)
        # 添加数据
        sql_session.add(new_session)
        # 提交变更
        sql_session.commit()
        # 打印数据
        sql_session.refresh(new_session)
        """关闭SQL会话
        # 其实用了with语句就不需要手动关闭了
        sql_session.close()
        """
        log.debug(f"添加会话: {new_session}")
        return new_session.id


def has_session(session_id: int) -> bool:
    with Session(engine) as sql_session:
        if sql_session.get(ChatSession, session_id):
            return True
        else:
            return False


def del_session(session_id: int) -> None:
    """
    删除会话
    """
    with Session(engine) as sql_session:
        session = sql_session.get(ChatSession, session_id)
        if session is not None:
            sql_session.delete(session)
            sql_session.commit()
            log.debug(f"删除会话: {session}")
        else:
            log.info(f"会话不存在: 会话ID{session_id}")


def update_session_title(session_id: int, new_title: str) -> None:
    with Session(engine) as sql_session:
        session = sql_session.get(ChatSession, session_id)
        session.title = new_title
        sql_session.commit()
        sql_session.refresh(session)
        log.debug(f"更改会话标题: {session}")

