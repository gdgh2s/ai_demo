# 构建链接
from sqlalchemy import create_engine
from sqlmodel import SQLModel

from config.init_dotenv import MySQL_USER, MYSQL_PASSWORD, MYSQL_HOST, MYSQL_PORT, MYSQL_DB

mysql_url = f"{MySQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
# 链接数据库
engine = create_engine(
    url=f"mysql+pymysql://{mysql_url}",
    # echo=True,  # 是否打印执行的SQL语句
)
SQLModel.metadata.bind = engine
