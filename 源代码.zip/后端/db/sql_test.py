from sqlmodel import SQLModel

from db.sql_engine import engine
from db.chat_messages import (
    add_system_message,
    add_human_message,
    add_ai_message,
    get_session_message
)
from db.chat_session import (
    create_session,
    update_session_title,
    del_session
)
from db.user import (
    add_user,
    del_user,
    update_user_name,
    available_user,
    unavailable_user,
    update_user_type
)

"""参考资料:
SQLModel官方教程网站: https://sqlmodel.tiangolo.com/tutorial
"""
if __name__ == '__main__':
    # 先删所有的表
    SQLModel.metadata.drop_all(engine)
    # 在创建所有的表
    SQLModel.metadata.create_all(engine)

    # 先删所有的表
    SQLModel.metadata.drop_all(engine)
    # 在创建所有的表
    SQLModel.metadata.create_all(engine)

    # 测试项1:添加用户
    add_user(name="李颖狰", type="admin", email="1423739550@qq.com",
             hashed_password="$2b$12$UvpVIJQc0KL2wzwpKYPlVe.n5nDg6VkfpL/vBjaZKq61N7GlBeLLO")

    # 测试2:修改用户名称
    update_user_name(user_id=1, new_name="李颖铮")

    # 测试3:修改用户权限
    update_user_type(user_id=1, new_type="normal")

    # 测试4:重复添加用户
    add_user(name="李颖狰", type="admin", email="1423739550@qq.com",
             hashed_password="$2b$12$UvpVIJQc0KL2wzwpKYPlVe.n5nDg6VkfpL/vBjaZKq61N7GlBeLLO")

    # 测试5:失活用户
    unavailable_user(user_id=1)

    # 测试6:激活用户
    available_user(user_id=1)

    # 测试7:创建会话
    create_session(user_id=1)

    # 测试8:修改会话标题
    update_session_title(session_id=1, new_title="测试会话")

    # 测试9:删除会话
    del_session(session_id=1)

    # 测试10:向删除的会话添加信息
    add_system_message(session_id=1, content="你是一个乐于助人的AI助手,帮助用户解决实际问题")

    # 测试11:添加消息
    create_session(user_id=1)
    add_system_message(session_id=2, content="你是一个乐于助人的AI助手,帮助用户解决实际问题。")
    add_human_message(session_id=2, content="您好,您能做个自我介绍吗?")
    add_ai_message(session_id=2, content="我是xxx,我是一个乐于助人的AI助手,帮助用户解决实际问题!")

    # 测试12:获取会话消息
    get_session_message(session_id=2)

    # 测试13:删除会话-级联删除,要确认数据库没有关联的消息
    # del_session(session_id=2)

    # 测试14:删除用户,要确认数据库没有关联的消息
    del_user(user_id=1)
