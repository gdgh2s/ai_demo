from sqlmodel import SQLModel

from db.sql_engine import engine
import user
import chat_session
import chat_messages
if __name__ == '__main__':
    # 先删所有的表
    SQLModel.metadata.drop_all(engine)
    # 在创建所有的表
    SQLModel.metadata.create_all(engine)
