from datetime import datetime
from typing import List

from sqlalchemy import Column
from sqlalchemy.dialects.mysql import LONGTEXT
from sqlmodel import Field, Session, SQLModel, Relationship

from db.chat_session import ChatSession
from db.sql_engine import engine
from config.log_config import log


# 创建 ChatMessage  模型
class ChatMessage(SQLModel, table=True):
    """
    用于存储对话消息的模型
    """
    __table_args__ = {'extend_existing': True}
    __tablename__ = 'message'
    # 字段
    id: int = Field(primary_key=True, nullable=False)
    role: str = Field(default="unknown", nullable=False)
    content: str = Field(title="Content", sa_column=Column("content", LONGTEXT))  # 非空字段
    created_at: datetime = Field(default_factory=datetime.now)  # 使用 default_factory
    is_available: bool = Field(default=False)
    # 外键
    session_id: int = Field(foreign_key="session.id", index=True)  # 级联删除
    # 关系
    session: List[ChatSession] = Relationship(back_populates="messages")

    def __str__(self):
        content_repr = self.content[:30] + "..." if len(self.content) > 30 else self.content
        created_at_repr = self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        return (
            f"ChatMessage(\n"
            f"  id={self.id!r}, \n"
            f"  session_id={self.session_id!r}, \n"
            f"  role={self.role!r}, \n"
            f"  content={content_repr!r}, \n"
            f"  created_at={created_at_repr!r}, \n"
            f"  is_available={self.is_available!r}\n"
            f")"
        )


def add_system_message(session_id: int, content: str) -> None:
    with Session(engine) as sql_session:
        if sql_session.get(ChatSession, session_id) is not None:
            message = ChatMessage(session_id=session_id, content=content, role="system")
            sql_session.add(message)
            sql_session.commit()
            sql_session.refresh(message)
            log.debug(f"添加系统消息: {message}")
        else:
            log.warning(f"添加系统消息失败: 会话ID不存在{session_id}")


def add_ai_message(session_id: int, content: str) -> None:
    # 构建SQL会话
    with Session(engine) as sql_session:
        if sql_session.get(ChatSession, session_id) is not None:
            message = ChatMessage(session_id=session_id, content=content, role="assistant")
            sql_session.add(message)
            sql_session.commit()
            sql_session.refresh(message)
            log.debug(f"添加AI消息: {message}")
        else:
            log.warning(f"添加AI消息失败: 会话ID不存在{session_id}")


def add_human_message(session_id: int, content: str) -> None:
    # 构建SQL会话
    with Session(engine) as sql_session:
        if sql_session.get(ChatSession, session_id) is not None:
            message = ChatMessage(session_id=session_id, content=content, role="user")
            sql_session.add(message)
            sql_session.commit()
            sql_session.refresh(message)
            log.debug(f"添加人类消息: {message}")
        else:
            log.warning(f"添加人类消息失败: 会话ID不存在{session_id}")


def delete_message(message_id: int) -> None:
    with Session(engine) as sql_session:
        message = sql_session.get(ChatMessage, message_id)
        sql_session.delete(message)
        sql_session.commit()
        sql_session.refresh(message)
        log.debug(f"删除消息: {message}")


def unavailable_message(message_id: int) -> None:
    # 构建SQL会话
    with Session(engine) as sql_session:
        """编写查询语句
        statement = select(message).where(message.id == message_id)
        result = session.exec(statement)
        # 但是下面的方法更便捷
        """
        # 通过 get 方法通过主键获取对象
        message = sql_session.get(ChatMessage, message_id)
        message.is_available = True
        sql_session.commit()
        sql_session.refresh(message)
        log.debug(f"弃用消息: {message}")


def get_session_message(session_id: int) -> List[ChatMessage] | None:
    # 构建SQL会话
    with Session(engine) as sql_session:
        if session := sql_session.get(ChatSession, session_id):
            log.debug(f"获取会话消息: {session.messages}")
            return session.messages
        else:
            log.warning(f"获取会话消息失败: 会话ID不存在{session_id}")
            return None
